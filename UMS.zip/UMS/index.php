<?php include('header.php')?>
<?php  

require "functions.php";

$errors = array();

if($_SERVER['REQUEST_METHOD'] == "POST")
{

	$errors = signup($_POST);

	if(count($errors) == 0)
	{
        $msg="";
		header("Location: verify.php");
		die;
	}
    else{
        $msg =$errors;
    }
}

?>
<!--Form to Add User-->
<h1 style="text-align:center">Home Page</h1>
<div class="testbox" id="form_sec">
    <div class="top-nav">
        <ul>
            <li class=""><a href="javascript:void(0);" target="_blank"></a></li>
            <li>Welcome to home page</li>
        </ul>
    </div>
    <form id="ticket_creation_form" name="ticket_creation_form" class="form" method="POST"
        enctype="multipart/form-data">
        <div class="amazon-sec" id="amazon-sec">
            <h2 style='text-align:center;' class="title_form">Add User Form
            </h2>
            <h5 style="color:#333; font-size:15px;">Please fill the below details</h5>

            <div class="colums">
                <div class="item form-field">
                    <label for="name">Name <span class="asterik">*</span></label>
                    <input type="text" class="mb-0" name="username" id="name" autocomplete="off"
                        placeholder="Enter Name" pattern="[A-Za-z ]{3,30}"
                        title="Please enter alphabets only and atleast 3 letters and maxlength 30" required="" />
                    <small id="error_name"></small>
                </div>
                <div class="item form-field">
                    <label for="email"> Email <span class="asterik">*</span></label>
                    <input type="email" class="mb-0" name="email" id="email" autocomplete="off"
                        placeholder="Enter Email" required="" />
                    <small id="error_email"></small>
                </div>
                <div class="item form-field">
                    <label for="password"> Password <span class="asterik">*</span></label>
                    <input type="password" class="mb-0" name="password" id="password" autocomplete="off"
                        placeholder="Enter Password" required="">
                    <small id="error_password"></small>
                </div>
                <div class="item form-field">
                    <label for="password"> Confirm Password <span class="asterik">*</span></label>
                    <input type="password" class="mb-0" name="password2" id="password2" autocomplete="off"
                        placeholder="Enter Password" required="">
                    <small id="error_password"></small>
                </div>
                <div class="item form-field">
                    <label for="mobileno"> Mobile Number <span class="asterik">*</span></label>
                    <input type="text" class="mb-0" name="mobileno" id="mobileno" autocomplete="off" pattern="[0-9]{10}"
                        title="Please Enter 10 Digit Mobile No. " placeholder="Enter Mobile Number" minlength="10"
                        maxlength="10" required="">
                    <small id="error_mobile"></small>
                </div>

            </div>
            <div id="error_details"></div>

        </div>
        <div class="btn-block">
            <button type="submit" id="submit" name="submit" class="btn">Add User</button>
        </div>

    </form>
</div>
<div class="error">
    <?php if($msg !== null){
   
   for($k=0; $k<count($msg); $k++){?>
    <input type="hidden" id="error_add_id" class="error_add_id" value="<?php echo $msg[$k]; ?>">
    <?php }
   }
   else{ echo $msg;?>
    <input type="hidden" id="error_add_id" class="error_add_id" value="">
    <?php
   }?>

</div>

<script>
//displaying errors
var error_arr = $(".error_add_id");
var err_div = "";
for (var e = 0; e < error_arr.length; e++) {

    if (error_arr[e].value != "" || error_arr[e].value != null) {

        err_div = err_div + "<div class='error-details'>" + error_arr[e].value + "</div>";
    } else {
        err_div = "";
    }
}
$("#error_details").html(err_div);
</script>
<?php include('footer.php')?>