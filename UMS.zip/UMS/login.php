<?php include('header.php')?>
<?php  

require "functions.php";

$errors = array();

if($_SERVER['REQUEST_METHOD'] == "POST")
{

	$errors = login($_POST);

	if(count($errors) == 0)
	{
        $msg="";
        $vars['email'] = $_SESSION['USER'];
        $query = "select email_verified from users where email = :email";
        $row= database_run($query,$vars);
        $arr = json_decode(json_encode($row), True);
        if($arr[0]['email_verified']=="verified"){
            header("Location: userslist.php");
        }
        else{
          header("Location: verify.php");
		  die;
        }
	}
    else{
        
        $msg =$errors;
    }
}

?>

<h1 style="text-align:center">Login</h1>
<div id="l-sec"></div>
<div class="testbox" id="form_sec">
    <div class="top-nav">
        <ul>
            <li class=""><a href="index.php" target="_blank"></a></li>
            <li>Welcome to Login page</li>
        </ul>
    </div>

    <form id="ticket_creation_form" name="ticket_creation_form" class="form" method="POST"
        enctype="multipart/form-data">
        <div class="amazon-sec" id="amazon-sec">
            <h2 style='text-align:center;' class="title_form">Login Form
            </h2>
            <h5 style="color:#333; font-size:15px;">Please fill the below details</h5>

            <div class="colums">
                <div class="item form-field">
                    <label for="email"> Email <span class="asterik">*</span></label>
                    <input type="email" class="mb-0" name="email" id="email" autocomplete="off"
                        placeholder="Enter Email" required="" />
                    <small id="error_email"></small>
                </div>
                <div class="item form-field">
                    <label for="password"> Password <span class="asterik">*</span></label>
                    <input type="password" class="mb-0" name="password" id="password" autocomplete="off"
                        placeholder="Enter Password" required="">
                    <small id="error_password"></small>
                </div>


            </div>
            <h2 id="error-details"></h2>


        </div>
        <div class="btn-block">
            <button type="submit" id="submit" name="submit" class="btn">Login</button>

        </div>

    </form>
</div>
<div class="error">
    <?php if($msg !== null){
   
   for($k=0; $k<count($msg); $k++){
     //var_dump($msg[$k]);?>
    <input type="hidden" id="error_id" value="<?php echo $msg[$k]; ?>">
    <?php }
   }
   else{ echo $msg[$k];?>
    <input type="hidden" id="error_id" value="">
    <?php
   }?>

</div>


<script>
if ($("#error_id").val() != "" || $("#error_id").val() != null) {


    $("#error-details").text($("#error_id").val())


} else {


    $("#error_id").text("");
    $("#error-details").text("");

}
</script>
<?php include('footer.php')?>