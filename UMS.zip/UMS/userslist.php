<?php

	require "functions.php";
?>

<?php include('header.php');?>
	<h1 style="text-align:center"> Users List</h1>


	<div class="container">
 <div class="row">
   <div class="col-sm-8">
    <div class="table-responsive">
      <table class="table table-bordered" id="my-table">
       <thead><tr><th>S.N</th>
         <th>Name</th>
         <th>Email</th>
         <th>Mobile Number</th>
         <th>Email Verified</th>
    </thead>
    <tbody>
  <?php
  $data= getdata();
      if(is_array($data)){      
      $sn=1;
		$array = json_decode(json_encode($data), True);
		
		  for($i=0; $i<count($array); $i++){
    ?>
      <tr>
      <td><?php echo $sn; ?></td>
      <td><?php echo $array[$i]['username']??''; ?></td>
      <td><?php echo $array[$i]['email']??''; ?></td>
      <td><?php echo $array[$i]['mobile']??''; ?></td>
      <td><?php if ($array[$i]['email_verified']==NULL || $array[$i]['email_verified']==""){
                    echo "Not Verified";
	  }else{
		echo $array[$i]['email_verified']??'';
	  }?></td>
     </tr>
     <?php
      $sn++;}}else{ ?>
      <tr>
        <td colspan="8">
    <?php echo $data; ?>
  </td>
    <tr>
    <?php
    }?>
    </tbody>
     </table>
   </div>
</div>
</div>
</div>
<div class="pagination">
	<ol id="numbers"></ol>
</div>
	
		


 <script>
	$(function() {
	const rowsPerPage = 13;
	const rows = $('#my-table tbody tr');
	const rowsCount = rows.length;
	const pageCount = Math.ceil(rowsCount / rowsPerPage); // avoid decimals
	const numbers = $('#numbers');
	
	// Generate the pagination.
	for (var i = 0; i < pageCount; i++) {
		// if(pageCount<3){
			console.log(pageCount);
		numbers.append('<li><a href="#">' + (i+1) + '</a></li>');
		//}
	}
		
	// Mark the first page link as active.
	$('#numbers li:first-child a').addClass('active');

	// Display the first set of rows.
	displayRows(1);
	
	// On pagination click.
	$('#numbers li a').click(function(e) {
		var $this = $(this);
		
		e.preventDefault();
		
		// Remove the active class from the links.
		$('#numbers li a').removeClass('active');
		
		// Add the active class to the current link.
		$this.addClass('active');
		
		// Show the rows corresponding to the clicked page ID.
		displayRows($this.text());
	});
	
	// Function that displays rows for a specific page.
	function displayRows(index) {
		var start = (index - 1) * rowsPerPage;
		var end = start + rowsPerPage;
		
		// Hide all rows.
		rows.hide();
		
		// Show the proper rows for this page.
		rows.slice(start, end).show();
	}
});
 </script>
	<?php include('footer.php');?>