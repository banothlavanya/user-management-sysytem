
<?php
//Define Base url
  function getBaseUrl(){
    return (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
   }
   if($_SERVER['HTTP_HOST'] == "localhost"){
    
    $baseUrl = getBaseUrl()."/UMS/";
}else{
    $baseUrl = getBaseUrl()."/UMS/";
}
define('BASE_URL', $baseUrl);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Home</title>
	<link rel="stylesheet" href="<?php echo BASE_URL?>css/style.css">
    <script src="<?php echo BASE_URL; ?>js/jquery.min.js"></script>
    
</head>
<body>
    <!--Fixed Header-->
<div class="fixed-header">
        <div class="container">
            <nav>
                <a href="index.php">Home</a>
                <a href="login.php">Login</a>
                <a href="userslist.php">Users List</a>
                <a href="logout.php">Logout</a>
            </nav>
        </div>
</div>