<?php include('header.php');?>
<?php

	require "mail.php";
	require "functions.php";
	check_login();
	$errors = array();
    //Generating the code in order to verfiy the email when the user is added
	if($_SERVER['REQUEST_METHOD'] == "GET" && !check_verified()){

		//send email
		$vars['code'] =  rand(10000,99999);
		//save to database
		$vars['expires'] = (time() + (60 * 10));
		$vars['email'] = $_SESSION['USER'];
		$query = "insert into verify (code,expires,email) values (:code,:expires,:email)";
		database_run($query,$vars);

		$message = "your code is " . $vars['code'];
		$subject = "Email verification";
		$recipient = $vars['email'];
		
		send_mail($recipient,$subject,$message);
	}
//verification of code, email and if verified then update the users email_verified column
	if($_SERVER['REQUEST_METHOD'] == "POST"){

		if(!check_verified()){
			$query = "select * from verify where code = :code && email = :email";
			$vars = array();
			$vars['email'] = $_SESSION['USER'];
			$vars['code'] = $_POST['code'];

			$row = database_run($query,$vars);

			if(is_array($row)){
				$row = $row[0];
				$time = time();

				if($row->expires > $time){

					$id = $_SESSION['USER'];
					$query = "update users set email_verified ='verified' where email = '$id' limit 1";
					
					database_run($query);

					header("Location: userslist.php");
					die;
				}else{
					$errors[]= "Code expired";
				}

			}else{
				$errors[]= "wrong code";
			}
		}else{
			$errors[]= "You're already verified";
		}
	}

?>

<div>
    <div>
        <?php if(count($errors) > 0):?>
        <?php foreach ($errors as $error):?>
        <input type="hidden" id="error_verifyid" value="<?php echo $error?>"></span><br>
        <?php endforeach;?>
        <?php endif;?>

    </div><br>
    <!--Verification Form-->
    <div class="testbox" id="form_sec">
        <div class="top-nav">
            <ul>
                <li class=""><a href="javascript:void(0)" target="_blank"></a></li>
                <li></li>
            </ul>
        </div>
        <form id="ticket_creation_form" name="ticket_creation_form" class="form" method="POST"
            enctype="multipart/form-data">
            <div class="amazon-sec" id="amazon-sec">
                <h2 style='text-align:center;' class="title_form">Email Verification Form
                </h2>
                <h5 style="color:#333; font-size:15px;">An email was sent to your address. Paste the code from the email
                    here and verify your email</h5>
                <div class="colums">
                    <div class="item form-field">
                        <label for="code">Verification Code<span class="asterik">*</span></label>
                        <input type="text" class="mb-0" name="code" id="code" autocomplete="off" pattern="[0-9]{5}"
                            title="Please Enter 5 Digit Code. " placeholder="Enter your Code" minlength="5"
                            maxlength="5" required="">

                    </div>

                </div>
                <h2 id="error-details"></h2>

            </div>
            <div class="btn-block">
                <button type="submit" id="submit" class="btn">Verify</button>
            
            </div>

        </form>
    </div>



</div>


<script>
	//Display the errors
if ($("#error_verifyid").val() != "" || $("#error_verifyid").val() != null) {


    $("#error-details").text($("#error_verifyid").val())


} else {


    $("#error_id").text("");
    $("#error-details").text("");

}
</script>
<?php include('footer.php');?>