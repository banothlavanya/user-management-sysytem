-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 03, 2023 at 11:43 AM
-- Server version: 8.0.32-0ubuntu0.22.04.2
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ums`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `email_verified` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `password` varchar(250) NOT NULL,
  `mobile` varchar(250) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `email_verified`, `password`, `mobile`, `date`) VALUES
(30, 'ada', 'ade@gmail.com', NULL, 'e5857b335afdf35ca81a110bc81f38682f8a89892cc597f5398dfef82d42b513', '8876867868', '2023-05-01 16:03:33'),
(31, 'dsdasd', 'a@gmail.com', NULL, '88d4266fd4e6338d13b845fcf289579d209c897823b9217da3e161936f031589', '6777777777', '2023-05-01 16:04:56'),
(50, 'abc', 'test@gmail.com', NULL, 'e5857b335afdf35ca81a110bc81f38682f8a89892cc597f5398dfef82d42b513', '9899898989', '2023-05-02 22:52:31'),
(51, 'testadmin', 'admin@gmail.com', NULL, '7676aaafb027c825bd9abab78b234070e702752f625b752e55e55b48e607e358', '4656856854', '2023-05-03 00:22:13'),
(53, 'test', 'adbcd@gmail.com', NULL, 'e5857b335afdf35ca81a110bc81f38682f8a89892cc597f5398dfef82d42b513', '9589898498', '2023-05-03 02:18:37'),
(54, 'lavanya', 'lavanya.b16@iiits.in', 'verified', 'e5857b335afdf35ca81a110bc81f38682f8a89892cc597f5398dfef82d42b513', '9989898998', '2023-05-03 10:46:20'),
(55, 'test', 'hi@gmail.com', NULL, 'e5857b335afdf35ca81a110bc81f38682f8a89892cc597f5398dfef82d42b513', '9069705970', '2023-05-03 11:04:23'),
(56, 'hello', 'hello@gmail.com', 'verified', 'e5857b335afdf35ca81a110bc81f38682f8a89892cc597f5398dfef82d42b513', '9898989898', '2023-05-03 11:09:36');

-- --------------------------------------------------------

--
-- Table structure for table `verify`
--

CREATE TABLE `verify` (
  `id` int NOT NULL,
  `code` int NOT NULL,
  `expires` int NOT NULL,
  `email` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `verify`
--

INSERT INTO `verify` (`id`, `code`, `expires`, `email`) VALUES
(1, 36864, 1682794479, 'lavanya.b16@iiits.in'),
(2, 86641, 1682794578, 'lavanya.b16@iiits.in'),
(3, 34309, 1682794672, 'lavanya.b16@iiits.in'),
(4, 56879, 1682847867, 'lavanya.b16@iiits.in'),
(5, 20058, 1682847869, 'lavanya.b16@iiits.in'),
(6, 59910, 1682847871, 'lavanya.b16@iiits.in'),
(7, 34148, 1682847873, 'lavanya.b16@iiits.in'),
(8, 98970, 1682847977, 'lavanya.b16@iiits.in'),
(9, 61499, 1682847979, 'lavanya.b16@iiits.in'),
(10, 49602, 1682847982, 'lavanya.b16@iiits.in'),
(11, 76211, 1682847984, 'lavanya.b16@iiits.in'),
(12, 79073, 1682848008, 'lavanya.b16@iiits.in'),
(13, 28185, 1682848572, 'lavanya.b16@iiits.in'),
(14, 32406, 1682848624, 'lavanya.b16@iiits.in'),
(15, 70798, 1682849830, 'lavanya.b16@iiits.in'),
(16, 16003, 1682849949, 'lavanya.b16@iiits.in'),
(17, 70901, 1682849986, 'lavanya.b16@iiits.in'),
(18, 64426, 1682850042, 'lavanya.b16@iiits.in'),
(19, 10346, 1682850185, 'lavanya.b16@iiits.in'),
(20, 16928, 1682850288, 'lavanya.b16@iiits.in'),
(21, 40099, 1682850388, 'lavanya.b16@iiits.in'),
(22, 88937, 1682850404, 'lavanya.b16@iiits.in'),
(23, 16668, 1682850443, 'lavanya.b16@iiits.in'),
(24, 96387, 1682850451, 'lavanya.b16@iiits.in'),
(25, 70465, 1682850468, 'lavanya.b16@iiits.in'),
(26, 63174, 1682850828, 'lavanya.b16@iiits.in'),
(27, 65229, 1682851127, 'lavanya.b16@iiits.in'),
(28, 31361, 1682851220, 'lavanya.b16@iiits.in'),
(29, 40237, 1682851303, 'lavanya.b16@iiits.in'),
(30, 63650, 1682851401, 'lavanya.b16@iiits.in'),
(31, 24687, 1682851451, 'lavanya.b16@iiits.in'),
(32, 25233, 1682851490, 'lavanya.b16@iiits.in'),
(33, 78025, 1682852483, 'lavanya.b16@iiits.in'),
(34, 27155, 1682852652, 'lavanya.b16@iiits.in'),
(35, 48860, 1682852929, 'lavanya.b@kapturecrm.com'),
(36, 24089, 1682853299, 'lavanya.b@kapturecrm.com'),
(37, 89534, 1682854270, 'lavanya.b16@iiits.in'),
(38, 69512, 1682854339, 'lavanya.b16@iiits.in'),
(39, 80421, 1682872811, 'lavanya.b@kapturecrm.com'),
(40, 35594, 1682872958, 'lavanya.b@kapturecrm.com'),
(41, 21542, 1682873089, 'lavanya.b@kapturecrm.com'),
(42, 78935, 1682873267, 'lavanya.b@kapturecrm.com'),
(43, 84009, 1682873317, 'lavanya.b@kapturecrm.com'),
(44, 25529, 1682873387, 'lavanya.b@kapturecrm.com'),
(45, 81407, 1682873686, 'lavanya.b@kapturecrm.com'),
(46, 58822, 1682873690, 'lavanya.b@kapturecrm.com'),
(47, 14642, 1682873694, 'lavanya.b@kapturecrm.com'),
(48, 45386, 1682873698, 'lavanya.b@kapturecrm.com'),
(49, 48025, 1682873784, 'lavanya.b@kapturecrm.com'),
(50, 37125, 1682873799, 'lavanya.b@kapturecrm.com'),
(51, 26957, 1682880916, 'lavanya.b@kapturecrm.com'),
(52, 43170, 1682881058, 'lavanya.b@kapturecrm.com'),
(53, 45922, 1682881099, 'lavanya.b@kapturecrm.com'),
(54, 16436, 1682883369, 'lavanya.b16@iiits.in'),
(55, 15928, 1682884124, 'lavanya.b16@iiits.in'),
(56, 45398, 1682884129, 'lavanya.b16@iiits.in'),
(57, 90619, 1682935755, 'lavanya.b16@iiits.in'),
(58, 20603, 1682939313, 'lavanya.b16@iiits.in'),
(59, 82969, 1682939451, 'lavanya.b16@iiits.in'),
(60, 87440, 1682939789, 'lavanya.b16@iiits.in'),
(61, 92811, 1682939831, 'lavanya.b16@iiits.in'),
(62, 68075, 1682939906, 'lavanya.b16@iiits.in'),
(63, 10167, 1682939973, 'lavanya.b16@iiits.in'),
(64, 52588, 1682940204, 'lavanya.b16@iiits.in'),
(65, 75732, 1682940648, 'lavanya.b16@iiits.in'),
(66, 41587, 1682940656, 'lavanya.b16@iiits.in'),
(67, 50704, 1682940999, 'lavanya.b16@iiits.in'),
(68, 46515, 1682941281, 'lavanya.b16@iiits.in'),
(69, 58655, 1682941676, 'lavanya.b16@iiits.in'),
(70, 87831, 1682941754, 'lavanya.b16@iiits.in'),
(71, 33258, 1682941993, 'lavanya.b16@iiits.in'),
(72, 47557, 1682965501, 'lavanya.b16@iiits.in'),
(73, 82610, 1682965594, 'lavanya.b16@iiits.in'),
(74, 67659, 1682965598, 'lavanya.b16@iiits.in'),
(75, 82902, 1682965602, 'lavanya.b16@iiits.in'),
(76, 62718, 1682965606, 'lavanya.b16@iiits.in'),
(77, 46101, 1682965610, 'lavanya.b16@iiits.in'),
(78, 33212, 1682965613, 'lavanya.b16@iiits.in'),
(79, 88191, 1682965670, 'lavanya.b16@iiits.in'),
(80, 59040, 1682965724, 'lavanya.b16@iiits.in'),
(81, 69509, 1682965767, 'lavanya.b16@iiits.in'),
(82, 95373, 1682966133, 'lavanya.b16@iiits.in'),
(83, 80004, 1682966644, 'lavanya.b16@iiits.in'),
(84, 93098, 1682966700, 'lavanya.b16@iiits.in'),
(85, 39455, 1683047038, 'lavanya.b16@iiits.in'),
(86, 65253, 1683047170, 'lavanya.b16@iiits.in'),
(87, 25150, 1683048751, 'test@gmail.com'),
(88, 53961, 1683052733, 'lavanya.b16@iiits.in'),
(89, 49228, 1683054133, 'admin@gmail.com'),
(90, 78548, 1683054197, 'admin@gmail.com'),
(91, 58548, 1683055018, 'lavanya.b16@iiits.in'),
(92, 34948, 1683055196, 'lavanya.b16@iiits.in'),
(93, 37471, 1683056074, 'admin@gmail.com'),
(94, 79083, 1683056111, 'admin@gmail.com'),
(95, 33437, 1683056161, 'admin@gmail.com'),
(96, 31209, 1683061117, 'adbcd@gmail.com'),
(97, 40245, 1683091580, 'lavanya.b16@iiits.in'),
(98, 54306, 1683092976, 'hello@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`),
  ADD KEY `username` (`username`),
  ADD KEY `date` (`date`);

--
-- Indexes for table `verify`
--
ALTER TABLE `verify`
  ADD PRIMARY KEY (`id`),
  ADD KEY `code` (`code`),
  ADD KEY `expires` (`expires`),
  ADD KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `verify`
--
ALTER TABLE `verify`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
